package com.cmr.graficos;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.camara.persistencia.ConfigDir;
import com.camara.persistencia.MisConexiones;

import com.interfaz.pojos.Cliente;
import com.nuevasfunciones.Cambiodefecha;
import com.nuevasfunciones.dameFecha;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Vector;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class PanelClientes extends JPanel {

	public DefaultTableModel dtm;
	JTable tabla;
	private int id;
	private JTextArea coment;
	JCheckBox box1;
	private int grupoPermisos;
	private ArrayList<JButton> botones;

	public PanelClientes() throws ClassNotFoundException, InstantiationException, IllegalAccessException {

		setLayout(new BorderLayout());
		add(creaTabla(), BorderLayout.CENTER);
		add(creaPanelNorte(), BorderLayout.NORTH);
		add(creaPanelEste(creaPanelDatos(), creaPanelControl()), BorderLayout.EAST);
		reset2();
		
	}// M�todo PanelClientes

	private JTextField txtId, txtname, txtApellido,txtdni_nie, txttlfno,txtmovil, txtcorreo, txtvivi, txtciu, txtpost, txtalta;
	private JCheckBox Res, Au;

	public JPanel creaPanelDatos() {

		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(105, 515));
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.add(Box.createRigidArea(new Dimension(0, 3)));

		// Creamos las etiquetas
		JLabel etId = new JLabel("Id Cliente");
		etId.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(etId);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		txtId = new JTextField(10);
		txtId.setMaximumSize(new Dimension(80, 20));
		txtId.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(txtId);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));

		JLabel etname = new JLabel("Nombre Cliente");
		etname.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(etname);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		txtname = new JTextField(10);
		txtname.setMaximumSize(new Dimension(80, 20));
		txtname.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(txtname);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));

		JLabel etApellido = new JLabel("Apellido Cliente");
		etApellido.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(etApellido);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		txtApellido = new JTextField(10);
		txtApellido.setMaximumSize(new Dimension(80, 20));
		txtApellido.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(txtApellido);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));

		JLabel etdni_nie = new JLabel("Dni Cliente");
		etdni_nie.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(etdni_nie);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		txtdni_nie = new JTextField(10);
		txtdni_nie.setMaximumSize(new Dimension(80, 20));
		txtdni_nie.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(txtdni_nie);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		
		JLabel ettlfno = new JLabel("Telefono");
		ettlfno.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(ettlfno);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		txttlfno = new JTextField(10);
		txttlfno.setMaximumSize(new Dimension(80, 20));
		txttlfno.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(txttlfno);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));

		JLabel etmovil = new JLabel("M�vil");
		etmovil.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(etmovil);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		txtmovil = new JTextField(10);
		txtmovil.setMaximumSize(new Dimension(80, 20));
		txtmovil.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(txtmovil);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));

		JLabel etcorreo = new JLabel("E-mail");
		etcorreo.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(etcorreo);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		txtcorreo = new JTextField(10);
		txtcorreo.setMaximumSize(new Dimension(80, 20));
		txtcorreo.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(txtcorreo);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));

		JLabel etvivi = new JLabel("Direcci�n_vivi");
		etvivi.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(etvivi);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		txtvivi = new JTextField(10);
		txtvivi.setMaximumSize(new Dimension(80, 20));
		txtvivi.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(txtvivi);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));

		JLabel etciu = new JLabel("Ciudad");
		etciu.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(etciu);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		txtciu = new JTextField(10);
		txtciu.setMaximumSize(new Dimension(80, 20));
		txtciu.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(txtciu);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));

		JLabel etalta = new JLabel("Fecha alta");
		etalta.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(etalta);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		txtalta = new JTextField(10);
		txtalta.setMaximumSize(new Dimension(80, 20));
		txtalta.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(txtalta);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));

		// Creamos un checkbox para Residente y Aut�nomo
		JLabel etres = new JLabel("Residente");
		etres.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(etres);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		Res = new JCheckBox();
		Res.setMaximumSize(new Dimension(80, 20));
		Res.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(Res);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));

		JLabel etauto = new JLabel("Aut�nomo");
		etauto.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(etauto);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		Au = new JCheckBox();
		Au.setMaximumSize(new Dimension(80, 20));
		Au.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(Au);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));

		return panel;

	}// M�todo creaPanelDatos

	public JPanel creaPanelControl() {

		// creat botones "A�adir, eliminar, editar
		// A�adir un check box

		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(120, 201));
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		panel.setBorder(BorderFactory.createLoweredBevelBorder());

		// Creamos los botones

		JButton boton1 = new JButton("Ver");
		boton1.addActionListener(new GestorVer());
		panel.add(boton1);
		boton1.setMaximumSize(new Dimension(80, 30));
		boton1.setBackground(Color.orange);

		JButton boton2 = new JButton("Actualizar");
		panel.add(boton2);
		boton2.setMaximumSize(new Dimension(80, 30));
		boton2.setBackground(Color.orange);

		JButton boton3 = new JButton("Insertar");
		panel.add(boton3);
		boton3.addActionListener(new GestorInsertar());
		boton1.addActionListener(new GestorVer());
		boton3.setBackground(Color.orange);
		boton3.setMaximumSize(new Dimension(80, 30));

		JButton boton4 = new JButton("Eliminar");
		panel.add(boton4);
		boton4.setMaximumSize(new Dimension(80, 30));
		boton4.addActionListener(new GestorBorrar());
		boton4.setBackground(Color.orange);

		JLabel etComentarios = new JLabel("Comentarios");
		coment = new JTextArea();
		etComentarios.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(etComentarios);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		coment.setMaximumSize(new Dimension(400, 150));
		coment.setAlignmentX(Component.CENTER_ALIGNMENT);
		coment.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
		panel.add(coment);
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		botones = new ArrayList<JButton>();
		botones.add(boton1);
		botones.add(boton2);
		botones.add(boton3);
		botones.add(boton4);
		
		box1 = new JCheckBox("�Habilitar?");
		panel.add(box1);
		box1.addActionListener(new GestorUsuario());
		
		
		for (int c = 0; c < botones.size() + 1; c++) {
            if (c < botones.size()) {
                botones.get(c).setMaximumSize(new Dimension(100, 20));
                panel.add(botones.get(c));
            } else
                panel.add(box1);
            panel.add(Box.createRigidArea(new Dimension(0, 3)));
            
		}

		botones.get(0).addActionListener(new GestorVer());
        botones.get(1).addActionListener(new GestorInsertar());
        botones.get(2).addActionListener(new GestorActualizar());
        botones.get(3).addActionListener(new GestorBorrar());
        
		return panel;

	}// m�todo creaPanelControl

	public class GestorVer implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			ResultSet rs = null;
			Vector<Object> v = null;
			Cliente cli = null;
			try {
				rs = new MisConexiones().dameResultSetSimple(ConfigDir.getInstance().getProperty("consulta1"));
				// Conexion con la consulta del CSDIR

				dtm.setRowCount(0);

				while (rs.next()) {
					v = new Vector<Object>();
					cli = new Cliente();
					cli.setId_cliente(rs.getInt("id_cliente"));
					cli.setNombre(rs.getString("Nombre"));
					cli.setApellidos(rs.getString("Apellidos"));
					cli.setDni_nie(rs.getString("Dni_nie"));
					cli.setTelefono(rs.getInt("Telefono"));
					cli.setMovil(rs.getInt("Movil"));
					cli.setEmail(rs.getString("Email"));
					cli.setDireccion(rs.getString("Direccion"));
					cli.setCiudad(rs.getString("Ciudad"));
					cli.setFecha_alta(rs.getTimestamp("Fecha_alta"));
					cli.setResidente(rs.getBoolean("Residente"));
					cli.setAutonomo(rs.getBoolean("Autonomo"));

					v.addElement(cli.getId_cliente());
					v.addElement(cli.getNombre());
					v.addElement(cli.getApellidos());
					v.addElement(cli.getDni_nie());
					v.addElement(cli.getTelefono());
					v.addElement(cli.getMovil());
					v.addElement(cli.getEmail());
					v.addElement(cli.getDireccion());
					v.addElement(cli.getCiudad());
					v.addElement(new dameFecha().formateoDateAqui(cli.getFecha_alta()));
					if (cli.isResidente())
						v.addElement("si");
					else
						v.addElement("no");

					if (cli.isAutonomo())
						v.addElement("si");
					else
						v.addElement("no");

					dtm.addRow(v);

				} // while
			} // try
			catch (Exception e2) {
				e2.printStackTrace();

			} // Catch

		}// ActionPerformed

	}// M�todo GestorVEr


	
	
	public class GestorActualizar implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			boolean c1, c2;
			if (Res.isSelected())
				c1 = true;
			else
				c1 = false;
			if (Au.isSelected())
				c2 = true;
			else
				c2 = false;
			try {
				int idAux = (Integer) dtm.getValueAt(id, 0);
				new MisConexiones().actualizarUsuario(ConfigDir.getInstance().getProperty("consulta4"),
						txtname.getText(), txtApellido.getText(), txtdni_nie.getText(),Integer.parseInt(txttlfno.getText()), Integer.parseInt(txtmovil.getText()), txtcorreo.getText(),
						txtvivi.getText(), txtciu.getText(),Timestamp.valueOf(txtalta.getText()), c1, c2, idAux).execute();
			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e2) {
				e2.printStackTrace();
			}
		}
	}
	
	
	public class GestorInsertar implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {

			boolean c1, c2;
			if (Res.isSelected())
				c1 = true;
			else
				c1 = false;

			if (Au.isSelected())
				c2 = true;
			else
				c2 = false;

			try {
				new MisConexiones().dameDatos(ConfigDir.getInstance().getProperty("consulta2"), 
						txtname.getText(),
						txtApellido.getText(),
						txtdni_nie.getText(), 
						Integer.parseInt(txttlfno.getText()),
						Integer.valueOf(txtmovil.getText()), 
						txtcorreo.getText(),
						txtvivi.getText(), 
						txtciu.getText(),new Timestamp(new java.util.Date().getTime()),
						c1,
						c2).execute();
				//new Timestamp(new java.util.Date().getTime()), c1, c2).execute();
			} catch (NumberFormatException | ClassNotFoundException | IllegalAccessException | SQLException
					| InstantiationException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();

			} // performed
		}// class

	}// M�todo GestorInsertar

	public JPanel creaPanelEste(JPanel p1, JPanel p2) {
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add(p1, BorderLayout.NORTH);
		panel.add(p2, BorderLayout.CENTER);

		return panel;

	}// CreaPanelESte
	
	

	public JPanel creaPanelNorte() {
		JPanel panelNorte = new JPanel();
		panelNorte.setLayout(new FlowLayout(FlowLayout.LEFT));
		JMenuBar jmenu = new JMenuBar();
		jmenu.setBorder(BorderFactory.createLoweredBevelBorder());
		JMenu busqueda = new JMenu("Filtrado");
		JMenuItem item1 = new JMenuItem("Por Residentes");
		JMenuItem item2 = new JMenuItem("Por Aut�nomos");
	
		

		busqueda.add(item1);
		busqueda.add(item2);
		
		
		item1.addActionListener(new GestorResidente());
		item2.addActionListener(new GestorAutonomo()); // LLamar al m�todo
		
		//item3.addActionListener(new GestorFecha());
		
		
		
		jmenu.add(busqueda);
		panelNorte.add(jmenu);
		

		return panelNorte;
	} // Del creaPanelNorte

	public JScrollPane creaTabla() throws ClassNotFoundException, InstantiationException, IllegalAccessException {

		dtm = new DefaultTableModel();
		dtm.addColumn("Id_cliente");
		dtm.addColumn("Nombre");
		dtm.addColumn("Apellido");
		dtm.addColumn("dni_nie");
		dtm.addColumn("Telefono_movil");
		dtm.addColumn("Movil");
		dtm.addColumn("E-mail");
		dtm.addColumn("Direcci�n_vivi");
		dtm.addColumn("Ciudad");
		dtm.addColumn("Fecha alta");
		dtm.addColumn("Residente");
		dtm.addColumn("Autonomo");

		tabla = new JTable(dtm);
		tabla.addMouseListener(new Gestortabla());
		JScrollPane sp = new JScrollPane(tabla);
		sp.setPreferredSize(new Dimension(824, 819));
		return sp;
	}// CreaTabla

	public class Gestortabla extends MouseAdapter {

		public void mouseReleased(MouseEvent e) {

			// dtm.setRowCount(0);
			int j = tabla.getSelectedRow();

			System.out.println(j);

			int entero1 = (int) dtm.getValueAt(j, 0);
			txtId.setText("" + entero1);

			String nom = (String) dtm.getValueAt(j, 1);
			txtname.setText(nom.toString());

			String ape = (String) dtm.getValueAt(j, 2);
			txtApellido.setText("" + ape);
			
			String dni = (String) dtm.getValueAt(j, 3);
			txtdni_nie.setText(""+dni);
			
			int entero2 = (int) dtm.getValueAt(j, 4);
			txttlfno.setText(""+entero2);

			int entero3 = (int) dtm.getValueAt(j, 5);
			txtmovil.setText("" + entero3);

			String email = (String) dtm.getValueAt(j, 6);
			txtcorreo.setText("" + email);

			String direc = (String) dtm.getValueAt(j, 7);
			txtvivi.setText("" + direc);

			String ciu = (String) dtm.getValueAt(j, 8);
			txtciu.setText("" + ciu);

			int entero4 = (int) dtm.getValueAt(j, 9);
			txtpost.setText("" + entero4);

			String fech = (String) dtm.getValueAt(j, 10);
			txtalta.setText("" + fech);

			if ((String) dtm.getValueAt(j, 11) == "si")
				Res.setSelected(true);
			else
				Res.setSelected(false);

			if ((String) dtm.getValueAt(j, 12) == "si")
				Au.setSelected(true);
			else
				Au.setSelected(false);

		}// GestorTabla
	}// PERMORMED

	public class GestorBorrar implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			int result = JOptionPane.showConfirmDialog(null, "�Seguro que desea borrar el usuario?", "Confirmar",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null);
			if (result == JOptionPane.YES_OPTION) {
				try {
					int j = tabla.getSelectedRow();
					int aux = (Integer) dtm.getValueAt(j, 0);
					new MisConexiones().BorrarUser(ConfigDir.getInstance().getProperty("consulta3"), aux).execute();
				} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e2) {
					e2.printStackTrace();
				}
			}//If

		}//ActionPerformed
	}// Gestorborrar

	
	public class GestorUsuario implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			String [] grupo = new String []{"1","2","3"};
			JFrame marcoUser = new JFrame ("Usuarios");
			marcoUser.setLocationRelativeTo(null);
			marcoUser.setSize(300,200);
			JPanel panelUser = new JPanel();
			marcoUser.add(panelUser);
			panelUser.setLayout(new BoxLayout(panelUser, BoxLayout.Y_AXIS));
			JLabel user = new JLabel("Usuario");
            JLabel Password = new JLabel("Contrase�a");
            JLabel grupos = new JLabel("Nivel del usuario");
            JTextField usuario_txt = new JTextField(10);
            JPasswordField password_txt = new JPasswordField(10);
            marcoUser.setVisible(true);
            

            if (marcoUser.isVisible())
                	box1.setEnabled(false);
            
         // Creamos lo necesario para el usuario
         			user.setAlignmentX(Component.CENTER_ALIGNMENT);
         			panelUser.add(user);
         			panelUser.add(Box.createRigidArea(new Dimension(0, 3)));
         			usuario_txt.setMaximumSize(new Dimension(150, 25));
         			usuario_txt.setAlignmentX(Component.CENTER_ALIGNMENT);
         			panelUser.add(usuario_txt);
         			panelUser.add(Box.createRigidArea(new Dimension(0, 3)));

         			// Creamos lo necesario para la constrase�a
         			Password.setAlignmentX(Component.CENTER_ALIGNMENT);
         			panelUser.add(Password);
         			panelUser.add(Box.createRigidArea(new Dimension(0, 3)));
         			password_txt.setMaximumSize(new Dimension(150, 25));
         			password_txt.setAlignmentX(Component.CENTER_ALIGNMENT);
         			panelUser.add(password_txt);
         			panelUser.add(Box.createRigidArea(new Dimension(0, 3)));

         			//Crear grupos
         			grupos.setAlignmentX(Component.CENTER_ALIGNMENT);
         			panelUser.add(grupos);
         			panelUser.add(Box.createRigidArea(new Dimension(0, 3)));
         			JComboBox<String> opciones = new JComboBox<String>(grupo);
         			opciones.setAlignmentX(Component.CENTER_ALIGNMENT);
         			opciones.setMaximumSize(new Dimension(150, 25));
         			panelUser.add(opciones);
         			panelUser.add(Box.createRigidArea(new Dimension(0, 3)));
         			
         			//Boton para identificarse
        			JButton login = new JButton("Identificarse");
        			login.setAlignmentX(Component.CENTER_ALIGNMENT);
        			login.setMaximumSize(new Dimension(150, 50));
        			panelUser.add(login);
        			panelUser.add(Box.createRigidArea(new Dimension(0, 3)));
        			
        			login.addActionListener(new ActionListener() {
        				public void actionPerformed(ActionEvent e) {
        					try {
        						char[] aux = password_txt.getPassword();
        						String valorGrupo = String.valueOf(opciones.getSelectedItem());
        						grupoPermisos = Integer.parseInt(valorGrupo);
        						final String password = String.copyValueOf(aux);
        						if (!(usuario_txt.getText().length() == 0) && !(password.length() == 0)) {
        							ResultSet rs = new MisConexiones()
        									.validarUser(ConfigDir.getInstance().getProperty("consulta9"),
        											usuario_txt.getText(), password, grupoPermisos)
        									.executeQuery();
        							if (rs.next()) {
        								JOptionPane.showMessageDialog(null, "Bienvenido " + usuario_txt.getText() + ".",
        										"Correcto", JOptionPane.INFORMATION_MESSAGE);
        								marcoUser.setVisible(false);
        								marcoUser.dispose();
        								if (!marcoUser.isVisible())
        									box1.setEnabled(true);
        								box1.setSelected(false);
        								reset(grupoPermisos);
        							} else {
        								JOptionPane.showMessageDialog(null,
        										"Los datos introducidos no coinciden con ning�n usuario.", "Error",
        										JOptionPane.ERROR_MESSAGE);
        								marcoUser.setVisible(false);
        								marcoUser.dispose();
        								if (!marcoUser.isVisible())
        									box1.setEnabled(true);
        								box1.setSelected(false);
        								reset(0);
        							}
        						} else {
        							JOptionPane.showMessageDialog(null, "No ha introducido datos.", "Error",
        									JOptionPane.ERROR_MESSAGE);
        							marcoUser.setVisible(false);
        							marcoUser.dispose();
        							if (!marcoUser.isVisible())
        								box1.setEnabled(true);
        							box1.setSelected(false);
        							reset(0);
        						}
        					} catch (Exception e1) {
        						e1.printStackTrace();
        					}
        				}
        			});
        			marcoUser.addWindowListener(new WindowListener() {
        				public void windowClosed(WindowEvent e) {
        				}

        				public void windowOpened(WindowEvent e) {
        				}

        				public void windowClosing(WindowEvent e) {
        					marcoUser.setVisible(false);
        					marcoUser.dispose();
        					if (!marcoUser.isVisible())
        						box1.setEnabled(true);
        					box1.setSelected(false);
        				}

        				public void windowIconified(WindowEvent e) {
        				}

        				public void windowDeiconified(WindowEvent e) {
        				}

        				public void windowActivated(WindowEvent e) {
        				}

        				public void windowDeactivated(WindowEvent e) {
        				}
        			});
			
		}//Performed
	}//Gestor
	
	private void reset2() {
		txtId.setEditable(false);
		txtname.setEditable(false);
		txtApellido.setEditable(false);
		txtdni_nie.setEditable(false);
		txtmovil.setEditable(false);
		txtcorreo.setEditable(false);
		txtvivi.setEditable(false); 
		txtciu.setEditable(false); 
		txtalta.setEditable(false);
		Res.setEnabled(false);
		Au.setEnabled(false);
		for ( int i=0; i<botones.size(); i++)
			botones.get(i).setEnabled(false);
	}
	
	private void reset(int grupoPermisos) {
        switch (grupoPermisos) {
        case 1:
        	reset2();
        	System.out.println("Administrador");
        	for (int i = 0; i < botones.size(); i++)
                botones.get(i).setEnabled(true);
        	//Administrador tendr� permiso en todo los botones
        	txtId.setEditable(true);
    		txtname.setEditable(true);
    		txtApellido.setEditable(true);
    		txtdni_nie.setEditable(true);
    		txtmovil.setEditable(true);
    		txtcorreo.setEditable(true);
    		txtvivi.setEditable(true); 
    		txtciu.setEditable(true); 
    		txtalta.setEditable(true);
    		Res.setEnabled(true);
    		Au.setEnabled(true);

            break;
        case 2:
        	reset2();
        	System.out.println("Jefe");
        	
        	//Jefe s�lo podra usar los botones Ver y Actualizar
        	botones.get(0).setEnabled(true);
        	botones.get(1).setEnabled(true);
        	txtId.setEditable(true);
    		txtname.setEditable(true);
    		txtApellido.setEditable(true);
    		txtdni_nie.setEditable(true);
    		txtmovil.setEditable(true);
    		txtcorreo.setEditable(true);
    		txtvivi.setEditable(true); 
    		txtciu.setEditable(true); 
    		txtalta.setEditable(true);
    		Res.setEnabled(true);
    		Au.setEnabled(true);


            break;
        case 3:
        	
        	reset2();
        	System.out.println("Empleado");
        	//Empleado solo podr� usar el botonVer
        	botones.get(0).setEnabled(true);
        	
        	txtId.setEditable(true);
    		txtname.setEditable(true);
    		txtApellido.setEditable(true);
    		txtdni_nie.setEditable(true);
    		txtmovil.setEditable(true);
    		txtcorreo.setEditable(true);
    		txtvivi.setEditable(true); 
    		txtciu.setEditable(true); 
    		txtalta.setEditable(true);
    		Res.setEnabled(true);
    		Au.setEnabled(true);


            break;
        }
    }
	public class GestorAutonomo implements ActionListener {
		@SuppressWarnings({ "unchecked", "rawtypes" })
		public void actionPerformed(ActionEvent e) {

			try {
				dtm.setRowCount(0);
				MisConexiones conexion = new MisConexiones();
				ResultSet rs = conexion.dameResultSetSimple(ConfigDir.getInstance().getProperty("consulta5"));
				// Conexion con la consulta del CSDIR

				Cliente cli = null;
				Vector v = null;
				Cambiodefecha ff = new Cambiodefecha();
				String fecha = "", boolAux = "";
				while (rs.next()) {
					cli = new Cliente();
					cli.setId_cliente(rs.getInt("Id_cliente"));
					cli.setNombre(rs.getString("Nombre_cliente"));
					cli.setApellidos(rs.getString("Apellido_cliente"));
					cli.setDni_nie(rs.getString("dni_nie"));
					cli.setMovil(rs.getInt("Telefono_movil"));
					cli.setEmail(rs.getString("email"));
					cli.setDireccion(rs.getString("Direcci�n_vivi"));
					cli.setCiudad(rs.getString("Ciudad"));
					cli.setFecha_alta(rs.getTimestamp("Fecha_alta"));
					cli.setResidente(rs.getBoolean("Residente"));
					cli.setAutonomo(rs.getBoolean("Aut�nomo"));
					v = new Vector();
					v.addElement(cli.getId_cliente());
					v.addElement(cli.getNombre());
					v.addElement(cli.getApellidos());
					v.addElement(cli.getDni_nie());
					v.addElement(cli.getMovil());
					v.addElement(cli.getEmail());
					v.addElement(cli.getDireccion());
					v.addElement(cli.getCiudad());
					fecha = ff.formateoDateAqui(cli.getFecha_alta());
					v.addElement(fecha);
					if (cli.isResidente())
						boolAux = "Si";
					else
						boolAux = "No";
					v.addElement(boolAux);
					if (cli.isAutonomo())
						boolAux = "Si";
					else
						boolAux = "No";
					v.addElement(boolAux);
					dtm.addRow(v);
				}
			} catch (Exception e2) {
				System.out.println(e2.getMessage());
			}
		}
	}

	public class GestorResidente implements ActionListener {
		@SuppressWarnings({ "unchecked", "rawtypes" })
		public void actionPerformed(ActionEvent e) {
			Cliente cli = null;
			ResultSet rs = null;
			Vector v = null;
			MisConexiones conexion = null;
			Cambiodefecha ff = new Cambiodefecha();
			String fecha = "", boolAux = "";
			try {
				// dtm.setRowCount(0);
				conexion = new MisConexiones();//

				rs = conexion.dameResultSetSimple(ConfigDir.getInstance().getProperty("consulta6"));
				// Conexi�n con la consulta del CSDIR

				while (rs.next()) {
					cli = new Cliente();
					cli.setId_cliente(rs.getInt("Id_cliente"));
					cli.setNombre(rs.getString("Nombre_cliente"));
					cli.setApellidos(rs.getString("Apellido_cliente"));
					cli.setDni_nie(rs.getString("dni_nie"));
					cli.setMovil(rs.getInt("Telefono_movil"));
					cli.setEmail(rs.getString("email"));
					cli.setDireccion(rs.getString("Direcci�n_vivi"));
					cli.setCiudad(rs.getString("Ciudad"));
					cli.setFecha_alta(rs.getTimestamp("Fecha_alta"));
					cli.setResidente(rs.getBoolean("Residente"));
					cli.setAutonomo(rs.getBoolean("Aut�nomo"));
					v = new Vector();
					v.addElement(cli.getId_cliente());
					v.addElement(cli.getNombre());
					v.addElement(cli.getApellidos());
					v.addElement(cli.getDni_nie());
					v.addElement(cli.getMovil());
					v.addElement(cli.getEmail());
					v.addElement(cli.getDireccion());
					v.addElement(cli.getCiudad());
					fecha = ff.formateoDateAqui(cli.getFecha_alta());
					v.addElement(fecha);
					if (cli.isResidente())
						boolAux = "Si";
					else
						boolAux = "No";
					v.addElement(boolAux);
					if (cli.isAutonomo())
						boolAux = "Si";
					else
						boolAux = "No";
					v.addElement(boolAux);
					dtm.addRow(v);

				}
			} catch (Exception e2) {
				System.out.println(e2.getMessage());
			}
		}
	}

}