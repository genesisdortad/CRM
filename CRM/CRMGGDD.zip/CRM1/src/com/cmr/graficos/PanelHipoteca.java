package com.cmr.graficos;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.*;

import javax.swing.*;
import javax.swing.table.*;

import com.camara.persistencia.ConfigDir;
import com.camara.persistencia.MisConexiones;
import com.interfaz.pojos.Cliente;
import com.interfaz.pojos.Hipotecadatos;
import com.nuevasfunciones.dameFecha;

import data.WordProcessing;

public class PanelHipoteca extends JPanel implements Serializable {

	public DefaultTableModel dtm;
	private JTable tabla;
	private JTextArea etNotas;
	ArrayList<JButton> botones;
	private JTextField finalidad, adquisicion, credito, plazo, drc_vivi, cargas;/* PRIMER PANEL */
	private JTextField vali, bqcl; /* PANEL PEQUE�O */
	private JTextField dni_nie, pam, sam, nom, fecha, pf, dom, pob, cop;/* DATOS PERSONALES */
	private JTextField nmp, adem, antd, pnm, demp, tlf_em; /* DATOS PROFESIONALES */
	private JTextField inf, inv, gad, ghc, ots, vavl, cgv, otbn, cgobt;/* DATOS ECONOMICOS */
	private JTextField txtNotas;

	private JComboBox<String> op1, op2, op3, op4; /* PRIMER PANEL */

	private JCheckBox edit, c1, c2, c3, c4; /* DATOS PERSONALES CHECKBOX */
	private JCheckBox d1, d2, d3, d4, d5, d6;/* DATOS ECONOMICOS */

	public PanelHipoteca() {
		setLayout(new BorderLayout());
		add(PanelNorte(), BorderLayout.NORTH);
		add(PanelOeste(), BorderLayout.WEST);
		add(PaneldelCentro(PanelCentral(), PanelControl()), BorderLayout.CENTER);
		add((PanelEste()), BorderLayout.EAST);
		add(PanelSur(), BorderLayout.SOUTH);
	}

	public JPanel PanelNorte() {
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.setPreferredSize(new Dimension(1275, 105));
		panel.add(Box.createRigidArea(new Dimension(0, 3)));
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.setBorder(BorderFactory.createLoweredBevelBorder());

		panel.add(PanelNorte1(), BorderLayout.NORTH);
		panel.add(PanelNorte2(), BorderLayout.SOUTH);
		return panel;
	}

	public JPanel PaneldelCentro(JPanel p2, JPanel p3) {
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add(p2, BorderLayout.NORTH);
		panel.add(p3, BorderLayout.CENTER);
		return panel;
	}

	private JPanel PanelNorte1() {
		JPanel dt = new JPanel();
		dt.setLayout(new FlowLayout(FlowLayout.LEFT));
		dt.setPreferredSize(new Dimension(1275, 75));

		JLabel fn = new JLabel(" FINALIDAD: ");
		fn.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(fn);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));
		finalidad = new JTextField(18);
		finalidad.setMaximumSize(new Dimension(60, 30));
		finalidad.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(finalidad);

		JLabel va = new JLabel("CR�DITO SOLICITADO:  Valor de adquisicion: ");
		va.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(va);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));
		adquisicion = new JTextField(16);
		adquisicion.setMaximumSize(new Dimension(60, 30));
		adquisicion.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(adquisicion);

		JLabel cr = new JLabel(" Importe Cr�dito: ");
		cr.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(cr);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));
		credito = new JTextField(13);
		credito.setMaximumSize(new Dimension(60, 30));
		credito.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(credito);

		JLabel pl = new JLabel(" Plazo Total (meses): ");
		pl.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(pl);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));
		plazo = new JTextField(10);
		plazo.setMaximumSize(new Dimension(90, 30));
		plazo.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(plazo);

		JLabel vivi = new JLabel(" Direcci�n Vivienda: ");
		vivi.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(vivi);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));
		drc_vivi = new JTextField(19);
		drc_vivi.setMaximumSize(new Dimension(50, 30));
		drc_vivi.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(drc_vivi);

		JLabel tp = new JLabel("Tipo: ");
		tp.setAlignmentX(Component.CENTER_ALIGNMENT);
		dt.add(tp);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));
		String[] gp1 = new String[] { "Libre", "C/cargos" };
		op1 = new JComboBox<String>(gp1);
		op1.setAlignmentX(Component.CENTER_ALIGNMENT);
		op1.setMaximumSize(new Dimension(60, 20));
		dt.add(op1);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));

		JLabel cg = new JLabel("Cargas");
		cg.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(cg);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));
		cargas = new JTextField(15);
		cargas.setMaximumSize(new Dimension(60, 30));
		cargas.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(cargas);

		JLabel nv = new JLabel("Nueva: ");
		nv.setAlignmentX(Component.CENTER_ALIGNMENT);
		dt.add(nv);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));
		String[] gp2 = new String[] { "Si", "No" };
		op2 = new JComboBox<String>(gp2);
		op2.setAlignmentX(Component.CENTER_ALIGNMENT);
		op2.setMaximumSize(new Dimension(60, 20));
		dt.add(op2);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));

		JLabel ec = new JLabel("Estado Civil: ");
		ec.setAlignmentX(Component.CENTER_ALIGNMENT);
		dt.add(ec);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));
		String[] gp3 = new String[] { "Soltero/a", "Casado/a", "Divorciado/a", "Separado/a" };
		op3 = new JComboBox<String>(gp3);
		op3.setAlignmentX(Component.CENTER_ALIGNMENT);
		op3.setMaximumSize(new Dimension(60, 20));
		dt.add(op3);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));

		JLabel rb = new JLabel("Regimen de Bienes: ");
		rb.setAlignmentX(Component.CENTER_ALIGNMENT);
		dt.add(rb);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));
		String[] gp4 = new String[] { "Separaci�n", "Gananciales", "Participacion" };
		op4 = new JComboBox<String>(gp4);
		op4.setAlignmentX(Component.CENTER_ALIGNMENT);
		op4.setMaximumSize(new Dimension(60, 20));
		dt.add(op4);
		dt.add(Box.createRigidArea(new Dimension(0, 3)));

		return dt;
	}

	private JPanel PanelNorte2() {
		JPanel sbn = new JPanel();
		sbn.setLayout(new FlowLayout(FlowLayout.CENTER));
		sbn.setMaximumSize(new Dimension(640, 30));
		sbn.setBorder(BorderFactory.createLoweredBevelBorder());

		JLabel vna = new JLabel("Vinculado a:");
		vna.setAlignmentX(Component.LEFT_ALIGNMENT);
		sbn.add(vna);
		sbn.add(Box.createRigidArea(new Dimension(0, 3)));
		vali = new JTextField(15);
		vali.setMaximumSize(new Dimension(40, 30));
		vali.setAlignmentX(Component.LEFT_ALIGNMENT);
		sbn.add(vali);

		JLabel bcl = new JLabel("Busqueda Cliente:");
		bcl.setAlignmentX(Component.LEFT_ALIGNMENT);
		sbn.add(bcl);
		sbn.add(Box.createRigidArea(new Dimension(0, 3)));
		bqcl = new JTextField(15);
		bqcl.setMaximumSize(new Dimension(40, 30));
		bqcl.setAlignmentX(Component.LEFT_ALIGNMENT);
		sbn.add(bqcl);

		JLabel impt = new JLabel("    dato aqui:");
		impt.setAlignmentX(Component.LEFT_ALIGNMENT);
		sbn.add(impt);
		sbn.add(Box.createRigidArea(new Dimension(0, 3)));

		return sbn;
	}

	private JPanel PanelOeste() {
		JPanel dt = new JPanel();
		dt.setLayout(new BoxLayout(dt, BoxLayout.Y_AXIS));
		dt.setPreferredSize(new Dimension(450, 900));
		dt.add(Box.createRigidArea(new Dimension(0, 8)));

		JLabel dp = new JLabel("DATOS PERSONALES:");
		dp.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(dp);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));

		JLabel tl = new JLabel("Titular:");
		tl.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		dt.add(tl);

		JLabel dni = new JLabel("Dnie/Nie:");
		dni.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(dni);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		dni_nie = new JTextField(10);
		dni_nie.setMaximumSize(new Dimension(100, 18));
		dni_nie.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(dni_nie);

		JLabel cr = new JLabel("Primer Apellido:");
		cr.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(cr);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		pam = new JTextField(10);
		pam.setMaximumSize(new Dimension(100, 18));
		pam.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(pam);

		JLabel pl = new JLabel("Segundo Apellido:");
		pl.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(pl);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		sam = new JTextField(10);
		sam.setMaximumSize(new Dimension(100, 18));
		sam.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(sam);

		JLabel vivi = new JLabel("Nombre:");
		vivi.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(vivi);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		nom = new JTextField(10);
		nom.setMaximumSize(new Dimension(100, 18));
		nom.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(nom);

		JLabel fcn = new JLabel("Fecha nacimiento:(dd/mm/yyyy)");
		fcn.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(fcn);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		fecha = new JTextField(10);
		fecha.setMaximumSize(new Dimension(100, 18));
		fecha.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(fecha);

		JLabel oc = new JLabel("OCUPACION:");
		oc.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(oc);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));

		JLabel etfijo = new JLabel("");
		etfijo.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(etfijo);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		c1 = new JCheckBox("Fijo");
		c1.setMaximumSize(new Dimension(100, 30));
		c1.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(c1);

		JLabel ettemp = new JLabel("");
		ettemp.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(ettemp);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		c2 = new JCheckBox("Temporal");
		c2.setMaximumSize(new Dimension(100, 30));
		c2.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(c2);

		JLabel etAutonomo = new JLabel("");
		etAutonomo.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(etAutonomo);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		c3 = new JCheckBox("Autonomo");
		c3.setMaximumSize(new Dimension(100, 30));
		c3.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(c3);

		JLabel etotros = new JLabel("");
		etotros.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(etotros);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		c4 = new JCheckBox("Otros");
		c4.setMaximumSize(new Dimension(100, 30));
		c4.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(c4);

		JLabel cg = new JLabel("Profesi�n:");
		cg.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(cg);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		pf = new JTextField(10);
		pf.setMaximumSize(new Dimension(100, 18));
		pf.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(pf);

		JLabel dm = new JLabel("Domicilio:");
		dm.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(dm);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		dom = new JTextField(10);
		dom.setMaximumSize(new Dimension(100, 18));
		dom.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(dom);

		JLabel pb = new JLabel("Poblaci�n:");
		pb.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(pb);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		pob = new JTextField(10);
		pob.setMaximumSize(new Dimension(100, 18));
		pob.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(pob);

		JLabel cp = new JLabel("C�digo Postal:");
		cp.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(cp);
		dt.add(Box.createRigidArea(new Dimension(0, 8)));
		cop = new JTextField(10);
		cop.setMaximumSize(new Dimension(100, 18));
		cop.setAlignmentX(Component.LEFT_ALIGNMENT);
		dt.add(cop);

		return dt;
	}

	private JPanel PanelCentral() {
		JPanel pe = new JPanel();
		pe.setLayout(new BoxLayout(pe, BoxLayout.Y_AXIS));
		pe.setPreferredSize(new Dimension(360, 320));
		pe.add(Box.createRigidArea(new Dimension(0, 10)));

		JLabel dp = new JLabel("DATOS PROFESIONALES:");
		dp.setAlignmentX(Component.LEFT_ALIGNMENT);
		pe.add(dp);
		pe.add(Box.createRigidArea(new Dimension(0, 10)));

		JLabel ne = new JLabel("Nombre de Empresa:");
		ne.setAlignmentX(Component.LEFT_ALIGNMENT);
		pe.add(ne);
		pe.add(Box.createRigidArea(new Dimension(0, 10)));
		nmp = new JTextField(10);
		nmp.setMaximumSize(new Dimension(360, 22));
		nmp.setAlignmentX(Component.LEFT_ALIGNMENT);
		pe.add(nmp);

		JLabel ade = new JLabel("Actividad de la empresa:");
		ade.setAlignmentX(Component.LEFT_ALIGNMENT);
		pe.add(ade);
		pe.add(Box.createRigidArea(new Dimension(0, 10)));
		adem = new JTextField(10);
		adem.setMaximumSize(new Dimension(360, 22));
		adem.setAlignmentX(Component.LEFT_ALIGNMENT);
		pe.add(adem);

		JLabel ant = new JLabel("Antiguedad:");
		ant.setAlignmentX(Component.LEFT_ALIGNMENT);
		pe.add(ant);
		pe.add(Box.createRigidArea(new Dimension(0, 10)));
		antd = new JTextField(10);
		antd.setMaximumSize(new Dimension(360, 22));
		antd.setAlignmentX(Component.LEFT_ALIGNMENT);
		pe.add(antd);

		JLabel pem = new JLabel("Puesto en la Empresa:");
		pem.setAlignmentX(Component.LEFT_ALIGNMENT);
		pe.add(pem);
		pe.add(Box.createRigidArea(new Dimension(0, 10)));
		pnm = new JTextField(10);
		pnm.setMaximumSize(new Dimension(360, 22));
		pnm.setAlignmentX(Component.LEFT_ALIGNMENT);
		pe.add(pnm);

		JLabel dem = new JLabel("Dirrecci�n de la empresa:");
		dem.setAlignmentX(Component.LEFT_ALIGNMENT);
		pe.add(dem);
		pe.add(Box.createRigidArea(new Dimension(0, 10)));
		demp = new JTextField(10);
		demp.setMaximumSize(new Dimension(360, 22));
		demp.setAlignmentX(Component.LEFT_ALIGNMENT);
		pe.add(demp);

		JLabel tfc = new JLabel("Telefono/fax/correo-e de la empresa:");
		tfc.setAlignmentX(Component.LEFT_ALIGNMENT);
		pe.add(tfc);
		pe.add(Box.createRigidArea(new Dimension(0, 10)));
		tlf_em = new JTextField(10);
		tlf_em.setMaximumSize(new Dimension(360, 22));
		tlf_em.setAlignmentX(Component.LEFT_ALIGNMENT);
		pe.add(tlf_em);

		return pe;
	}

	private JPanel PanelControl() {
		JPanel pc = new JPanel();
		pc.setLayout(new BoxLayout(pc, BoxLayout.Y_AXIS));
		pc.setPreferredSize(new Dimension(250, 200));
		pc.setBorder(BorderFactory.createLoweredBevelBorder());
		JLabel de = new JLabel("PANEL DE CONTROL");
		de.setAlignmentX(Component.CENTER_ALIGNMENT);
		pc.add(Box.createRigidArea(new Dimension(0, 10)));
		pc.add(de);

		JButton imp = new JButton("IMPRIMIR PETICION");
		imp.addActionListener(new GestionImprimirPeticion());

		JButton add = new JButton("INSERTAR EN LA BBDD");
		add.addActionListener(new GestorInsertarBBDD());

		JButton lm = new JButton("LIMPIAR");
		lm.addActionListener(new GestionLimpiar());

		JButton ver = new JButton("VER DATOS");
		ver.addActionListener(new Gestorvertabla());

		botones = new ArrayList<JButton>();
		botones.add(imp);
		botones.add(add);
		botones.add(lm);
		botones.add(ver);

		edit = new JCheckBox("EDITAR CAMPOS");
		edit.setAlignmentX(Component.CENTER_ALIGNMENT);

		for (int c = 0; c < botones.size() + 1; c++) {
			if (c < botones.size()) {
				botones.get(c).setMaximumSize(new Dimension(170, 30));
				botones.get(c).setAlignmentX(Component.CENTER_ALIGNMENT);
				pc.add(botones.get(c));
			} else
				pc.add(edit);
			pc.add(Box.createRigidArea(new Dimension(0, 25)));

		}

		etNotas = new JTextArea();
		etNotas.setLineWrap(true);
		etNotas.setWrapStyleWord(true);
		etNotas.setPreferredSize(new Dimension(250, 180));
		JScrollPane sp = new JScrollPane(etNotas);
		sp.setHorizontalScrollBar(null);
		sp.setPreferredSize(new Dimension(250, 180));
		sp.setAlignmentX(Component.CENTER_ALIGNMENT);
		sp.setBorder(BorderFactory.createLoweredBevelBorder());
		pc.add(sp);

		return pc;
	}

	private JPanel PanelEste() {
		JPanel pdc = new JPanel();
		pdc.setLayout(new BoxLayout(pdc, BoxLayout.Y_AXIS));
		pdc.setPreferredSize(new Dimension(450, 900));
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));

		JLabel de = new JLabel("DATOS ECONOMICOS:");
		de.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(de);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));

		JLabel in = new JLabel("Ingresos Fijos (mes):");
		in.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(in);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		inf = new JTextField(10);
		inf.setMaximumSize(new Dimension(100, 18));
		inf.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(inf);

		JLabel va = new JLabel("Ingresos Variables (mes):");
		va.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(va);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		inv = new JTextField(10);
		inv.setMaximumSize(new Dimension(120, 18));
		inv.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(inv);

		JLabel ga = new JLabel("Gastos alquiler:");
		ga.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(ga);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		gad = new JTextField(10);
		gad.setMaximumSize(new Dimension(120, 18));
		gad.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(gad);

		JLabel gh = new JLabel("Gastos Hipoteca:");
		gh.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(gh);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		ghc = new JTextField(10);
		ghc.setMaximumSize(new Dimension(120, 18));
		ghc.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(ghc);

		JLabel ot = new JLabel("Otros:");
		ot.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(ot);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		ots = new JTextField(10);
		ots.setMaximumSize(new Dimension(120, 18));
		ots.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(ots);

		JLabel viv = new JLabel("Valor Vivienda:");
		viv.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(viv);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		vavl = new JTextField(10);
		vavl.setMaximumSize(new Dimension(120, 18));
		vavl.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(vavl);

		JLabel cv = new JLabel("Cargas Vivienda:");
		cv.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(cv);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		cgv = new JTextField(10);
		cgv.setMaximumSize(new Dimension(120, 18));
		cgv.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(cgv);

		JLabel etpd = new JLabel("");
		etpd.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(etpd);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		d1 = new JCheckBox("propiedad");
		d1.setMaximumSize(new Dimension(120, 30));
		d1.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(d1);

		JLabel etes = new JLabel("");
		etes.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(etes);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		d2 = new JCheckBox("escritura");
		d2.setMaximumSize(new Dimension(120, 30));
		d2.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(d2);

		JLabel etcp = new JLabel("");
		etcp.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(etcp);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		d3 = new JCheckBox("contrato privado");
		d3.setMaximumSize(new Dimension(120, 30));
		d3.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(d3);

		JLabel etot = new JLabel("");
		etot.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(etot);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		d4 = new JCheckBox("otros");
		d4.setMaximumSize(new Dimension(120, 30));
		d4.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(d4);

		JLabel etpdd = new JLabel("");
		etpdd.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(etpdd);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		d5 = new JCheckBox("padres");
		d5.setMaximumSize(new Dimension(120, 30));
		d5.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(d5);

		JLabel etal = new JLabel("");
		etal.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(etal);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		d6 = new JCheckBox("alquiler");
		d6.setMaximumSize(new Dimension(120, 30));
		d6.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(d6);

		JLabel otb = new JLabel("Otros Bienes:");
		otb.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(otb);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		otbn = new JTextField(10);
		otbn.setMaximumSize(new Dimension(120, 18));
		otbn.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(otbn);

		JLabel cobt = new JLabel("Cargos Otros Bienes:");
		cobt.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(cobt);
		pdc.add(Box.createRigidArea(new Dimension(0, 8)));
		cgobt = new JTextField(10);
		cgobt.setMaximumSize(new Dimension(120, 18));
		cgobt.setAlignmentX(Component.RIGHT_ALIGNMENT);
		pdc.add(cgobt);
		return pdc;
	}

	private JScrollPane PanelSur() {
		// JScrollPane sr = new JScrollPane();
		dtm = new DefaultTableModel();

		dtm.addColumn("id");
		dtm.addColumn("ape1");
		dtm.addColumn("ape2");
		dtm.addColumn("nombre");
		dtm.addColumn("dni_nie");
		dtm.addColumn("fijo");
		dtm.addColumn("temporal");
		dtm.addColumn("autonomo");
		dtm.addColumn("otro");
		dtm.addColumn("ocupacion");
		dtm.addColumn("profesion");
		dtm.addColumn("domicilio");
		dtm.addColumn("poblacion");
		dtm.addColumn("codpost");
		dtm.addColumn("fecha_nac");
		dtm.addColumn("valadq");
		dtm.addColumn("impcto");
		dtm.addColumn("plazoTot");
		dtm.addColumn("dirvivi");
		dtm.addColumn("tipovivi");
		dtm.addColumn("Cargas");
		dtm.addColumn("nueva");
		dtm.addColumn("estadocivil");
		dtm.addColumn("regbienes");
		dtm.addColumn("vinculo");

		tabla = new JTable(dtm);
		TableColumn column = null;
		for (int i = 0; i < dtm.getColumnCount(); i++) {
			column = tabla.getColumnModel().getColumn(i);
			column.setMinWidth(120);
			column.setPreferredWidth(120);
		}

		tabla.setBounds(0, 0, 1280, 185);
		tabla.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		JScrollPane sp = new JScrollPane(tabla, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		sp.setPreferredSize(new Dimension(1200, 100));
		sp.setBorder(BorderFactory.createLoweredBevelBorder());

		sp.add(Box.createRigidArea(new Dimension(1200, 100)));
		return sp;
	}

	public class GestionImprimirPeticion implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			WordProcessing.createNewDocumentFromTemplate("credHipo.dotx");
			WordProcessing.typeTextAtBookmark("activemp", adem.getText());
			WordProcessing.typeTextAtBookmark("activemp_conyu", "2");
			WordProcessing.typeTextAtBookmark("alquiler", cambioS(d6.isSelected()));
			WordProcessing.typeTextAtBookmark("alquiler_conyu", "4");
			WordProcessing.typeTextAtBookmark("antig", "5");
			WordProcessing.typeTextAtBookmark("antiguo", antd.getText());
			WordProcessing.typeTextAtBookmark("antiguo_conyu", "7");
			WordProcessing.typeTextAtBookmark("ape1", pam.getText());
			WordProcessing.typeTextAtBookmark("ape1_conyu", "9");
			WordProcessing.typeTextAtBookmark("ape2", sam.getText());
			WordProcessing.typeTextAtBookmark("ape2_conyu", "11");
			WordProcessing.typeTextAtBookmark("aut", cambioS(c3.isSelected()));
			WordProcessing.typeTextAtBookmark("aut_conyu", "13");
			WordProcessing.typeTextAtBookmark("cargas", cargas.getText());
			WordProcessing.typeTextAtBookmark("cargasotrosbi", cgobt.getText());
			WordProcessing.typeTextAtBookmark("cargasotrosbi_conyu", "16");
			WordProcessing.typeTextAtBookmark("cargasvivi", cgv.getText());
			WordProcessing.typeTextAtBookmark("cargasvivi_conyu", "18");
			WordProcessing.typeTextAtBookmark("contratpriv", cambioS(d3.isSelected()));
			WordProcessing.typeTextAtBookmark("contratpriv_conyu", "20");
			WordProcessing.typeTextAtBookmark("cp_conyu", "21");
			WordProcessing.typeTextAtBookmark("credito", credito.getText());
			WordProcessing.typeTextAtBookmark("diremp", demp.getText());
			WordProcessing.typeTextAtBookmark("diremp_conyu", "24");
			WordProcessing.typeTextAtBookmark("dirviv", drc_vivi.getText());
			WordProcessing.typeTextAtBookmark("dni_nie", dni_nie.getText());
			WordProcessing.typeTextAtBookmark("dni_nie_conyu", "27");
			WordProcessing.typeTextAtBookmark("dom", dom.getText());
			WordProcessing.typeTextAtBookmark("dom_conyu", "29");
			WordProcessing.typeTextAtBookmark("escritura", cambioS(d2.isSelected()));
			WordProcessing.typeTextAtBookmark("escritura_conyu", "31");
			WordProcessing.typeTextAtBookmark("cp", cop.getText());
			WordProcessing.typeTextAtBookmark("estadcivil", op3.getSelectedItem().toString());
			WordProcessing.typeTextAtBookmark("fechan", fecha.getText());
			WordProcessing.typeTextAtBookmark("fechan_conyu", "35");
			WordProcessing.typeTextAtBookmark("fijo", cambioS(c1.isSelected()));
			WordProcessing.typeTextAtBookmark("fijo_conyu", "37");
			WordProcessing.typeTextAtBookmark("fijosmen", inf.getText());
			WordProcessing.typeTextAtBookmark("fijosmen_conyu", "39");
			WordProcessing.typeTextAtBookmark("fin", finalidad.getText());
			WordProcessing.typeTextAtBookmark("gastosalq", gad.getText());
			WordProcessing.typeTextAtBookmark("gastosalq_conyu", "42");
			WordProcessing.typeTextAtBookmark("gastoshipo", ghc.getText());
			WordProcessing.typeTextAtBookmark("gastoshipo_conyu", "44");
			WordProcessing.typeTextAtBookmark("nombrecli", nom.getText());
			WordProcessing.typeTextAtBookmark("nombrecli_conyu", "46");
			WordProcessing.typeTextAtBookmark("nomemp", nmp.getText());
			WordProcessing.typeTextAtBookmark("nomemp_conyu", "48");
			WordProcessing.typeTextAtBookmark("nueva", op2.getSelectedItem().toString());
			WordProcessing.typeTextAtBookmark("otros", cambioS(c4.isSelected()));
			WordProcessing.typeTextAtBookmark("otros_conyu", "51");
			WordProcessing.typeTextAtBookmark("otrosbipat", otbn.getText());
			WordProcessing.typeTextAtBookmark("otrosbipat_conyu", "53");
			WordProcessing.typeTextAtBookmark("otrosmas", "54");
			WordProcessing.typeTextAtBookmark("otrosmas_conyu", "55");
			WordProcessing.typeTextAtBookmark("otrospat", cambioS(d4.isSelected()));
			WordProcessing.typeTextAtBookmark("otrospres", ots.getText());
			WordProcessing.typeTextAtBookmark("otrospres_conyu", "58");
			WordProcessing.typeTextAtBookmark("padres", cambioS(d5.isSelected()));
			WordProcessing.typeTextAtBookmark("padres_conyu", "60");
			WordProcessing.typeTextAtBookmark("plazotot", plazo.getText());
			WordProcessing.typeTextAtBookmark("pob", pob.getText());
			WordProcessing.typeTextAtBookmark("pob_conyu", "63");
			WordProcessing.typeTextAtBookmark("posicion", pnm.getText());
			WordProcessing.typeTextAtBookmark("posicion_conyu", "65");
			WordProcessing.typeTextAtBookmark("prof", pf.getText());
			WordProcessing.typeTextAtBookmark("prof_conyu", "67");
			WordProcessing.typeTextAtBookmark("propiedad", cambioS(d1.isSelected()));
			WordProcessing.typeTextAtBookmark("propiedad_conyu", "69");
			WordProcessing.typeTextAtBookmark("regimen", op4.getSelectedItem().toString());
			WordProcessing.typeTextAtBookmark("regimen_conyu", "71");
			WordProcessing.typeTextAtBookmark("telemp", tlf_em.getText());
			WordProcessing.typeTextAtBookmark("telemp_conyu", "73");
			WordProcessing.typeTextAtBookmark("tipo", op1.getSelectedItem().toString());
			WordProcessing.typeTextAtBookmark("valad", adquisicion.getText());
			WordProcessing.typeTextAtBookmark("valorvivi", vavl.getText());
			WordProcessing.typeTextAtBookmark("valorvivi_conyu", "77");
			WordProcessing.typeTextAtBookmark("varmen", inv.getText());
			WordProcessing.typeTextAtBookmark("varmen_conyu", "79");
			WordProcessing.typeTextAtBookmark("temp", cambioS(c2.isSelected()));
			WordProcessing.typeTextAtBookmark("temp_conyu", "81");

			WordProcessing.exec();
		}
	}

	public class GestionLimpiar implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			finalidad.setText("");
			adquisicion.setText("");
			credito.setText("");
			plazo.setText("");
			drc_vivi.setText("");
			cargas.setText("");

			vali.setText("");
			bqcl.setText("");
			dni_nie.setText("");
			pam.setText("");
			sam.setText("");
			nom.setText("");
			fecha.setText("");
			pf.setText("");
			dom.setText("");
			pob.setText("");
			cop.setText("");

			nmp.setText("");
			adem.setText("");
			antd.setText("");
			pnm.setText("");
			demp.setText("");
			tlf_em.setText("");

			inf.setText("");
			inv.setText("");
			gad.setText("");
			ghc.setText("");
			ots.setText("");
			vavl.setText("");
			cgv.setText("");
			otbn.setText("");
			cgobt.setText("");

			// Limpiamos los checkbox

			c1.setSelected(false);
			c2.setSelected(false);
			c3.setSelected(false);
			c4.setSelected(false);

			d1.setSelected(false);
			d2.setSelected(false);
			d3.setSelected(false);
			d4.setSelected(false);
			d5.setSelected(false);
			d6.setSelected(false);

			// Limpiamos los JComboBox

			op1.setSelectedIndex(0);
			op2.setSelectedIndex(0);
			op3.setSelectedIndex(0);
			op4.setSelectedIndex(0);

		}
	}

	public String cambioS(boolean flag) {

		String control = null;
		if (flag != true)
			control = "no";
		else
			control = "si";
		return control;
	}

	public class Gestorvertabla implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			ResultSet rs = null;
			Vector<Object> v = null;
			Hipotecadatos hipo = null;
			try {
				rs = new MisConexiones().dameResultSetSimple(ConfigDir.getInstance().getProperty("consulta10"));
				// Conexion con la consulta del CSDIR

				dtm.setRowCount(0);

				while (rs.next()) {
					v = new Vector<Object>();
					hipo = new Hipotecadatos();
					hipo.setId(rs.getInt("id"));
					hipo.setApe1(rs.getString("ape1"));
					hipo.setApe2(rs.getString("ape2"));
					hipo.setNombre(rs.getString("nombre"));
					hipo.setDni_nie(rs.getString("dni_nie"));
					hipo.setFijo(rs.getBoolean("fijo"));
					hipo.setTemporal(rs.getBoolean("temporal"));
					hipo.setAutonomo(rs.getBoolean("autonomo"));
					hipo.setOtro(rs.getBoolean("otro"));
					hipo.setOcupacion(rs.getString("ocupacion"));
					hipo.setProfesion(rs.getString("profesion"));
					hipo.setDomicilio(rs.getString("domicilio"));
					hipo.setPoblacion(rs.getString("poblacion"));
					hipo.setCodpost(rs.getInt("codpost"));
					hipo.setFecha_nac(rs.getTimestamp("fecha_nac"));
					hipo.setValadq(rs.getInt("valadq"));
					hipo.setImpcto(rs.getInt("impcto"));
					hipo.setPlazoTot(rs.getInt("plazoTot"));
					hipo.setDirvivi(rs.getString("dirvivi"));
					hipo.setTipovivi(rs.getString("tipovivi"));
					hipo.setCargas(rs.getInt("Cargas"));
					hipo.setNueva(rs.getString("nueva"));
					hipo.setEstadocivil(rs.getString("estadocivil"));
					hipo.setRegbienes(rs.getString("regbienes"));
					hipo.setVinculo(rs.getString("vinculo"));

					v.addElement(hipo.getId());
					v.addElement(hipo.getApe1());
					v.addElement(hipo.getApe2());
					v.addElement(hipo.getNombre());
					v.addElement(hipo.getDni_nie());
					v.addElement(hipo.getOcupacion());
					v.addElement(hipo.getProfesion());
					v.addElement(hipo.getDomicilio());
					v.addElement(hipo.getPoblacion());
					v.addElement(hipo.getCodpost());
					v.addElement(hipo.getFecha_nac());
					v.addElement(hipo.getValadq());
					v.addElement(hipo.getImpcto());
					v.addElement(hipo.getPlazoTot());
					v.addElement(hipo.getDirvivi());
					v.addElement(hipo.getTipovivi());
					v.addElement(hipo.getCargas());
					v.addElement(hipo.getNueva());
					v.addElement(hipo.getEstadocivil());
					v.addElement(hipo.getRegbienes());
					v.addElement(hipo.getVinculo());

					if (hipo.isFijo())
						v.addElement("si");
					else
						v.addElement("no");

					if (hipo.isTemporal())
						v.addElement("si");
					else
						v.addElement("no");

					if (hipo.isAutonomo())
						v.addElement("si");
					else
						v.addElement("no");

					if (hipo.isOtro())
						v.addElement("si");
					else
						v.addElement("no");

					dtm.addRow(v);

				} // while
			} // try
			catch (Exception e2) {
				e2.printStackTrace();

			} // Catch

		}// ActionPerformed

	}// M�todo GestorVEr
	
	
	public class GestorInsertar implements ActionListener{
	public void actionPerfomed(ActionEvent e) {
		
		}
	}

/*	public class GestorInsertarBBDD implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			try {
				new MisConexiones().dametodos(ConfigDir.getInstance().getProperty("consulta8"), dni_nie.getText(),
						pam.getText(), sam.getText(), nom.getText(), new Timestamp(new java.util.Date().getTime()),
						c1.isSelected(), c2.isSelected(), c3.isSelected(), c4.isSelected(), pf.getText(), dom.getText(),
						pob.getText(), Integer.parseInt(cop.getText()), nmp.getText(), adem.getText(), antd.getText(),
						pnm.getText(), demp.getText(), Integer.parseInt(tlf_em.getText()),
						Integer.parseInt(inf.getText()), Integer.parseInt(inv.getText()),
						Integer.parseInt(gad.getText()), Integer.parseInt(ghc.getText()),
						Integer.parseInt(ots.getText()), Integer.parseInt(vavl.getText()),
						Integer.parseInt(cgv.getText()), d1.isSelected(), d2.isSelected(), d3.isSelected(),
						d4.isSelected(), d5.isSelected(), d6.isSelected(), otbn.getText(),
						Integer.parseInt(cgobt.getText())).execute();

			} catch (NumberFormatException | ClassNotFoundException | IllegalAccessException | SQLException
					| InstantiationException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();

			} // actionPermorfed
		}// Class   */ 

	}
}
