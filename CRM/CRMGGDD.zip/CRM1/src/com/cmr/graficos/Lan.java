package com.cmr.graficos;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;


import java.awt.event.KeyEvent;
import java.io.IOException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Lan {

	private static String licencia = " ";
	private static JFrame marco = new JFrame("CRM :)");

	private static ImageIcon iconito = new ImageIcon("Imagen/batman.jpg");
	
	

	static class Calculadora implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			String[] comandito = new String[] { "Calc.exe" };
			try {
				Runtime.getRuntime().exec(comandito);
			}  catch (IOException e1) {
				e1.printStackTrace();
			} // catch
		}// public
	}// M�todo

	static class Google implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String[] comandito2 = new String[] { "microsoftedge", "http://www.google.es" };
			try {
				Runtime.getRuntime().exec(comandito2);
			} catch (IOException e1) {
				e1.printStackTrace();
			} // catch
		}// Public
	}// M�todo

//Boolean boolean

	public static void main(String[] args)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException {

		licencia = (String) JOptionPane.showInputDialog(null, "Licencia:  ", null, JOptionPane.PLAIN_MESSAGE, iconito,
				null, null);
		if (licencia != null) {
			switch (licencia) {
			case "0034":
				Marco1();

				break;
			default:
				marco.setVisible(false);
				

			}// Switch

		} // if
		else {

			marco.setVisible(false);
		} // else
	}

	public static void Marco1() throws ClassNotFoundException, InstantiationException, IllegalAccessException {

			

		// top y left
		marco.setLocation(0, 0);

		Toolkit tk = Toolkit.getDefaultToolkit();
		// Panel con varias pesta�as (dos)
		JTabbedPane pestanias = new JTabbedPane();
		pestanias.add("Directorio cliente", new PanelClientes()); // Pesta�a
		pestanias.add("Hipoteca", new PanelHipoteca());
		// Lo metemos en el frame (aqui se visualiza)

		marco.getContentPane().add(pestanias);
		

		// Damos dimensi�n a nuestro marco seg�n tama�o de la pantalla
		Dimension dim = tk.getScreenSize();
		System.out.println(dim.width + "," + dim.height);
		marco.setSize(1050,800);
		marco.setVisible(true);

		JMenuBar menub = new JMenuBar();
		JMenu fileMenu = new JMenu("Accesos directos");
		fileMenu.setMnemonic(KeyEvent.VK_F);
		menub.add(fileMenu);

		// 1er Item
		JMenuItem newMenuItem = new JMenuItem("Calculadora");
		fileMenu.add(newMenuItem);
		newMenuItem.addActionListener(new Calculadora());
		marco.setJMenuBar(menub);
		
		// 2doItem
		JMenuItem newMenuItem2 = new JMenuItem("Google");
		fileMenu.add(newMenuItem2);
		newMenuItem2.addActionListener(new Google());
		marco.setJMenuBar(menub);
		menub.setVisible(true);
		menub.setSize(350, 250);

	} // panel

}// CLASE
