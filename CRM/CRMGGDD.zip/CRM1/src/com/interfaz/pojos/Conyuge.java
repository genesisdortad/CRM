package com.interfaz.pojos;

import java.sql.Timestamp;

public class Conyuge {
 //Datos del conyuge su getter and setter
	//Una consulta que nos de los datos del panel hipoteca
	
	String NombreC;
	String Apellido1C;
	String Apellido2C;
	String DniC;
	Timestamp fecha_nacC;
	String ProfesionC;
	
	public String getNombreC() {
		return NombreC;
	}
	public void setNombreC(String nombreC) {
		NombreC = nombreC;
	}
	public String getApellido1C() {
		return Apellido1C;
	}
	public void setApellido1C(String apellido1c) {
		Apellido1C = apellido1c;
	}
	public String getApellido2C() {
		return Apellido2C;
	}
	public void setApellido2C(String apellido2c) {
		Apellido2C = apellido2c;
	}
	public String getDniC() {
		return DniC;
	}
	public void setDniC(String dniC) {
		DniC = dniC;
	}
	public Timestamp getFecha_nacC() {
		return fecha_nacC;
	}
	public void setFecha_nacC(Timestamp fecha_nacC) {
		this.fecha_nacC = fecha_nacC;
	}
	public String getProfesionC() {
		return ProfesionC;
	}
	public void setProfesionC(String profesionC) {
		ProfesionC = profesionC;
	}
	
	
	
	
	
	
	
}
