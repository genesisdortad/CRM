package com.interfaz.pojos;

public class Usuario {

	int Id_usuario;
	String Alias_usuario;
	String Password;
	int Nivel_usuario;
	
	public int getId_usuario() {
		return Id_usuario;
	}
	public void setId_usuario(int id_usuario) {
		Id_usuario = id_usuario;
	}
	public String getAlias_usuario() {
		return Alias_usuario;
	}
	public void setAlias_usuario(String alias_usuario) {
		Alias_usuario = alias_usuario;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public int getNivel_usuario() {
		return Nivel_usuario;
	}
	public void setNivel_usuario(int nivel_usuario) {
		Nivel_usuario = nivel_usuario;
	}
	

}
