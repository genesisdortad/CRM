package com.camara.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class MisConexiones {

	private Connection con;
	private PreparedStatement ps;
	private Statement st; // para crear databases con setencias SQL
	private ResultSet rs;
	private String sentencia;
	private String parametro;
	private String parametro2;
	private ConfigDir atrapo;

	public MisConexiones() throws ClassNotFoundException, InstantiationException, IllegalAccessException {

		atrapo = ConfigDir.getInstance();
		if (atrapo.getBooleanProperty("check"))
			;
		Class.forName(atrapo.getProperty("driver"));

	}

	public Connection getConexion() throws SQLException {
		return con;

	}

	public Connection dameConexion() throws SQLException {
		con = DriverManager.getConnection(atrapo.getProperty("cadena"), atrapo.getProperty("user"),
				atrapo.getProperty("conex"));
		return con;
	}
	public PreparedStatement validarUser(String sentencia, String parametro, String parametro2, int parametro3)
            throws SQLException {
        this.sentencia = sentencia;
        this.parametro = parametro;
        this.parametro2 = parametro2;
        ps = dameConexion().prepareStatement(sentencia);
        ps.setString(1, parametro);
        ps.setString(2, parametro2);
        ps.setInt(3, parametro3);
        return ps;
    } 
	
	
	
	
	
	public PreparedStatement dameDatos(String sentencia, String Nom, String Ap, String DNI, int TF,int TM, String Em, String Dir,
			String Ci, Timestamp Fe, boolean Re, boolean Au) throws SQLException {
		this.sentencia = sentencia;
		ps = dameConexion().prepareStatement(sentencia);
		ps.setString(1, Nom);
		ps.setString(2, Ap);
		ps.setString(3, DNI);
		ps.setInt(4, TF);
		ps.setInt(5, TM);
		ps.setString(6, Em);
		ps.setString(7, Dir);
		ps.setString(8, Ci);
		ps.setTimestamp(9, Fe);
		ps.setBoolean(10, Re);
		ps.setBoolean(11, Au);
		return ps;
	}

	public PreparedStatement damePSSimple(String sentencia) throws SQLException {

		this.sentencia = sentencia;
		ps = dameConexion().prepareStatement(sentencia);

		return ps;
	}

	public ResultSet dameResultSetSimple(String sentencia) throws SQLException {

		this.sentencia = sentencia;
		rs = damePSSimple(sentencia).executeQuery();
		return rs;
	}

	public PreparedStatement BorrarUser(String sentencia, int id) throws SQLException {
		
		JOptionPane elimin = new JOptionPane();
		//elimin.set;
		JDialog dialogo = elimin.createDialog(sentencia);
		dialogo.show();
		Object selectedValue = elimin.getValue();
		
		this.sentencia = sentencia;
		ps = dameConexion().prepareStatement(sentencia);
		ps.setInt(1, id);
		return ps;
	}

	public PreparedStatement actualizarUsuario(String sentencia, String Nom, String Ap,String DNI,int TF, int TM, String Em, String Dir,
			String Ci, Timestamp Fe, boolean Re, boolean Au, int id) throws SQLException {
		this.sentencia = sentencia;
		ps = dameConexion().prepareStatement(sentencia);
		ps.setString(1, Nom);
		ps.setString(2, Ap);
		ps.setString(3, DNI);
		ps.setInt(4, TF);
		ps.setInt(5, TM);
		ps.setString(6, Em);
		ps.setString(7, Dir);
		ps.setString(8, Ci);
		ps.setTimestamp(9, Fe);
		ps.setBoolean(10, Re);
		ps.setBoolean(11, Au);
		ps.setInt(12, id);
		return ps;
	}
	
	public PreparedStatement dametodos(String sentencia, String DNI,String AP1, String AP2, String N1,
			Timestamp fechanac,boolean fijo, boolean tempo, boolean auton, boolean otros,
			String profe, String domi,String pobla, int codpost,
			String nombreempre, String actiempre, String antig, String puesto, String direcempre, int teleempre,
			int ingrefijo, int ingrevar, int gasalq, int gashipo, int otrosgas, int valvivi, int cargasvivi,
			boolean propi, boolean escri, boolean contrato, boolean otropropi, boolean padres, 
			boolean alquiler,String otrosbienes, int cargosotros) throws SQLException {
		this.sentencia = sentencia;
		ps = dameConexion().prepareStatement(sentencia);
		ps.setString(1, DNI);
		ps.setString(2, AP1);
		ps.setString(3, AP2);
		ps.setString(4, N1);
		ps.setTimestamp(5, fechanac);
		
		ps.setBoolean(6, fijo);
		ps.setBoolean(7, tempo);
		ps.setBoolean(8, auton);
		ps.setBoolean(9, otros);
		ps.setString(10, profe);
		ps.setString(11, domi);
		ps.setString(12, pobla);
		ps.setInt(13, codpost);
		
	/*	ps.setString(14, nombreempre);
		ps.setString(15, actiempre);
		ps.setString(16, antig);
		ps.setString(17, puesto);
		ps.setString(18, direcempre);
		ps.setInt(19, teleempre);
		
		ps.setInt(20, ingrefijo);
		ps.setInt(21, ingrevar);
		ps.setInt(22, gasalq);
		ps.setInt(23, gashipo);
		ps.setInt(24, otrosgas);
		ps.setInt(25, valvivi);
		ps.setInt(26, cargasvivi);
		ps.setBoolean(27, propi);
		ps.setBoolean(28, escri);
		ps.setBoolean(29, contrato);
		ps.setBoolean(30, otropropi);
		ps.setBoolean(31, padres);
		ps.setBoolean(32, alquiler);
		ps.setString(33, otrosbienes);
		ps.setInt(34, cargosotros);		
	*/
		
		return ps;
		
	}
	
	
}